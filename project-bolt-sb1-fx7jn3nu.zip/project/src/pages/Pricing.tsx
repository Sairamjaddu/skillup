import React from 'react';
import { Check, Star, Crown } from 'lucide-react';

const Pricing: React.FC = () => {
  const plans = [
    {
      name: 'Self-Paced',
      description: 'Perfect for independent learners',
      price: 1999,
      originalPrice: 2999,
      features: [
        'Access to all video courses',
        'Downloadable resources',
        'Community access',
        'Basic progress tracking',
        'Email support',
        'Mobile app access',
        'Lifetime access to purchased courses'
      ],
      popular: false,
      buttonText: 'Get Started',
      buttonStyle: 'border border-purple-600 text-purple-600 hover:bg-purple-50'
    },
    {
      name: 'Live Classes',
      description: 'Interactive learning with peers',
      price: 3999,
      originalPrice: 5999,
      features: [
        'Everything in Self-Paced',
        'Live interactive classes',
        'Real-time Q&A sessions',
        'Group projects',
        'Peer networking',
        'Live coding sessions',
        'Scheduled assessments',
        'Class recordings'
      ],
      popular: true,
      buttonText: 'Start Learning',
      buttonStyle: 'bg-purple-600 text-white hover:bg-purple-700'
    },
    {
      name: 'Premium Mentoring',
      description: 'Personalized 1-on-1 guidance',
      price: 7999,
      originalPrice: 12999,
      features: [
        'Everything in Live Classes',
        '4 one-on-one mentoring sessions',
        'Personalized learning path',
        'Code review sessions',
        'Career guidance',
        'Resume review',
        'Interview preparation',
        'Direct mentor WhatsApp access',
        'Priority support'
      ],
      popular: false,
      buttonText: 'Go Premium',
      buttonStyle: 'bg-gradient-to-r from-purple-600 to-pink-600 text-white hover:from-purple-700 hover:to-pink-700'
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-16">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">
            Choose Your Learning Path
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Select the perfect plan for your learning style and career goals. 
            All plans include our quality guarantee and student support.
          </p>
        </div>

        {/* Pricing Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-16">
          {plans.map((plan, index) => (
            <div
              key={index}
              className={`relative bg-white rounded-2xl shadow-lg overflow-hidden ${
                plan.popular ? 'ring-2 ring-purple-600 transform scale-105' : ''
              }`}
            >
              {plan.popular && (
                <div className="absolute top-0 left-0 right-0 bg-gradient-to-r from-purple-600 to-pink-600 text-white text-center py-2 text-sm font-medium">
                  <Star className="inline w-4 h-4 mr-1" />
                  Most Popular
                </div>
              )}

              <div className={`p-8 ${plan.popular ? 'pt-16' : ''}`}>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <h3 className="text-2xl font-bold text-gray-900">{plan.name}</h3>
                    <p className="text-gray-600">{plan.description}</p>
                  </div>
                  {index === 2 && (
                    <Crown className="w-8 h-8 text-yellow-500" />
                  )}
                </div>

                <div className="mb-6">
                  <div className="flex items-baseline">
                    <span className="text-4xl font-bold text-gray-900">
                      ₹{plan.price.toLocaleString()}
                    </span>
                    <span className="text-gray-500 ml-2 line-through">
                      ₹{plan.originalPrice.toLocaleString()}
                    </span>
                  </div>
                  <p className="text-sm text-green-600 font-medium mt-1">
                    Save ₹{(plan.originalPrice - plan.price).toLocaleString()}
                  </p>
                </div>

                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-start">
                      <Check className="w-5 h-5 text-purple-600 mr-3 mt-0.5 flex-shrink-0" />
                      <span className="text-gray-700">{feature}</span>
                    </li>
                  ))}
                </ul>

                <button className={`w-full py-3 px-6 rounded-lg font-semibold transition-colors ${plan.buttonStyle}`}>
                  {plan.buttonText}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* FAQ Section */}
        <div className="max-w-4xl mx-auto">
          <h2 className="text-3xl font-bold text-gray-900 mb-8 text-center">
            Frequently Asked Questions
          </h2>
          <div className="space-y-6">
            {[
              {
                question: "Can I upgrade my plan later?",
                answer: "Yes! You can upgrade to any higher plan at any time. You'll only pay the difference between your current plan and the new one."
              },
              {
                question: "Do you offer refunds?",
                answer: "We offer a 30-day money-back guarantee for all our courses. If you're not satisfied, we'll refund your payment in full."
              },
              {
                question: "How long do I have access to the courses?",
                answer: "All courses come with lifetime access. Once purchased, you can access the content forever, including any future updates."
              },
              {
                question: "Can I pause my mentoring sessions?",
                answer: "Yes, you can pause and resume your mentoring sessions as needed. Your session credits remain valid for 12 months from purchase."
              },
              {
                question: "Are there any hidden fees?",
                answer: "No hidden fees ever. The price you see is exactly what you pay. All materials, resources, and support are included."
              }
            ].map((faq, index) => (
              <div key={index} className="bg-white rounded-lg shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-900 mb-3">
                  {faq.question}
                </h3>
                <p className="text-gray-600 leading-relaxed">
                  {faq.answer}
                </p>
              </div>
            ))}
          </div>
        </div>

        {/* Guarantee Section */}
        <div className="mt-16 bg-gradient-to-br from-purple-50 to-pink-50 rounded-2xl p-8 text-center">
          <div className="max-w-3xl mx-auto">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">
              Our 30-Day Success Guarantee
            </h2>
            <p className="text-lg text-gray-600 mb-6">
              We're so confident in our courses that if you don't see progress in your skills 
              within 30 days, we'll refund your money completely. No questions asked.
            </p>
            <div className="flex flex-col sm:flex-row justify-center items-center space-y-4 sm:space-y-0 sm:space-x-6">
              <div className="flex items-center space-x-2">
                <Check className="w-5 h-5 text-green-600" />
                <span className="text-gray-700">30-day guarantee</span>
              </div>
              <div className="flex items-center space-x-2">
                <Check className="w-5 h-5 text-green-600" />
                <span className="text-gray-700">No questions asked</span>
              </div>
              <div className="flex items-center space-x-2">
                <Check className="w-5 h-5 text-green-600" />
                <span className="text-gray-700">Full refund</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Pricing;