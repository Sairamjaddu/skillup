import React from 'react';
import { Calendar, Clock, Users, MapPin } from 'lucide-react';
import { liveClasses } from '../data/mockData';
import { useAuth } from '../context/AuthContext';
import { useNavigate } from 'react-router-dom';

const LiveClasses: React.FC = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  const handleBookClass = (classItem: any) => {
    if (!user) {
      navigate('/login');
      return;
    }

    // Simulate Razorpay payment
    const options = {
      key: 'rzp_test_1234567890',
      amount: classItem.price * 100,
      currency: 'INR',
      name: 'Skills.do',
      description: classItem.title,
      handler: function(response: any) {
        alert('Booking successful! You will receive a Google Meet link via email.');
      },
      prefill: {
        name: user.name,
        email: user.email,
      },
      theme: {
        color: '#6A0DAD'
      }
    };

    // @ts-ignore
    const rzp = new window.Razorpay(options);
    rzp.open();
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4">Live Classes</h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            Join interactive live sessions with expert instructors and fellow learners
          </p>
        </div>

        {/* Upcoming Classes */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {liveClasses.map((classItem) => (
            <div key={classItem.id} className="bg-white rounded-xl shadow-md overflow-hidden hover:shadow-xl transition-all duration-300">
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <span className="bg-green-100 text-green-800 px-3 py-1 rounded-full text-sm font-medium">
                    Live
                  </span>
                  <span className="text-2xl font-bold text-purple-600">
                    ₹{classItem.price.toLocaleString()}
                  </span>
                </div>

                <h3 className="text-xl font-bold text-gray-900 mb-3">
                  {classItem.title}
                </h3>

                <p className="text-gray-600 mb-4">
                  {classItem.description}
                </p>

                <div className="space-y-3 mb-6">
                  <div className="flex items-center space-x-3 text-sm text-gray-600">
                    <Calendar className="w-4 h-4" />
                    <span>{new Date(classItem.date).toLocaleDateString()}</span>
                  </div>
                  <div className="flex items-center space-x-3 text-sm text-gray-600">
                    <Clock className="w-4 h-4" />
                    <span>{classItem.time} ({classItem.duration})</span>
                  </div>
                  <div className="flex items-center space-x-3 text-sm text-gray-600">
                    <Users className="w-4 h-4" />
                    <span>{classItem.enrolledStudents}/{classItem.maxStudents} enrolled</span>
                  </div>
                  <div className="flex items-center space-x-3 text-sm text-gray-600">
                    <MapPin className="w-4 h-4" />
                    <span>By {classItem.instructor}</span>
                  </div>
                </div>

                <div className="mb-4">
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-purple-600 h-2 rounded-full"
                      style={{
                        width: `${(classItem.enrolledStudents / classItem.maxStudents) * 100}%`
                      }}
                    ></div>
                  </div>
                  <p className="text-sm text-gray-600 mt-2">
                    {classItem.maxStudents - classItem.enrolledStudents} spots left
                  </p>
                </div>

                <button
                  onClick={() => handleBookClass(classItem)}
                  className="w-full bg-purple-600 text-white py-3 px-6 rounded-lg font-semibold hover:bg-purple-700 transition-colors"
                  disabled={classItem.enrolledStudents >= classItem.maxStudents}
                >
                  {classItem.enrolledStudents >= classItem.maxStudents ? 'Fully Booked' : 'Book Now'}
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Benefits Section */}
        <div className="mt-16 bg-white rounded-xl shadow-sm p-8">
          <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
            Why Join Our Live Classes?
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Interactive Learning</h3>
              <p className="text-gray-600">
                Engage directly with instructors and ask questions in real-time
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Structured Schedule</h3>
              <p className="text-gray-600">
                Follow a structured learning path with regular live sessions
              </p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Clock className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Time Efficient</h3>
              <p className="text-gray-600">
                Learn faster with focused, intensive live sessions
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default LiveClasses;