import { Course, LiveClass, Session } from '../types';

export const courses: Course[] = [
  {
    id: '1',
    title: 'Full Stack Web Development',
    description: 'Master modern web development with React, Node.js, and MongoDB. Build real-world projects and deploy them.',
    instructor: 'Sarah Johnson',
    price: 2499,
    duration: '12 weeks',
    level: 'Intermediate',
    image: 'https://images.pexels.com/photos/574071/pexels-photo-574071.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.8,
    students: 1250,
    category: 'Web Development',
    modules: ['HTML/CSS Basics', 'JavaScript ES6+', 'React Fundamentals', 'Node.js & Express', 'Database Design', 'Deployment']
  },
  {
    id: '2',
    title: 'Data Science with Python',
    description: 'Learn data analysis, visualization, and machine learning with Python. Perfect for beginners and professionals.',
    instructor: 'Dr. Michael Chen',
    price: 3499,
    duration: '16 weeks',
    level: 'Beginner',
    image: 'https://images.pexels.com/photos/669615/pexels-photo-669615.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.9,
    students: 980,
    category: 'Data Science',
    modules: ['Python Basics', 'NumPy & Pandas', 'Data Visualization', 'Statistics', 'Machine Learning', 'Projects']
  },
  {
    id: '3',
    title: 'UI/UX Design Masterclass',
    description: 'Create stunning user interfaces and experiences. Learn Figma, design principles, and user research.',
    instructor: 'Emma Rodriguez',
    price: 1999,
    duration: '10 weeks',
    level: 'Beginner',
    image: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.7,
    students: 2100,
    category: 'Design',
    modules: ['Design Principles', 'Figma Mastery', 'User Research', 'Wireframing', 'Prototyping', 'Portfolio']
  },
  {
    id: '4',
    title: 'Mobile App Development',
    description: 'Build native iOS and Android apps using React Native. Deploy to app stores and monetize your apps.',
    instructor: 'Alex Thompson',
    price: 2999,
    duration: '14 weeks',
    level: 'Advanced',
    image: 'https://images.pexels.com/photos/607812/pexels-photo-607812.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.6,
    students: 850,
    category: 'Mobile Development',
    modules: ['React Native Setup', 'Navigation', 'State Management', 'APIs & Storage', 'Publishing', 'Monetization']
  },
  {
    id: '5',
    title: 'Digital Marketing Bootcamp',
    description: 'Master SEO, social media, content marketing, and analytics. Grow your brand and drive conversions.',
    instructor: 'Lisa Park',
    price: 1799,
    duration: '8 weeks',
    level: 'Beginner',
    image: 'https://images.pexels.com/photos/270348/pexels-photo-270348.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.5,
    students: 1850,
    category: 'Marketing',
    modules: ['SEO Fundamentals', 'Social Media Strategy', 'Content Creation', 'Email Marketing', 'Analytics', 'Campaigns']
  },
  {
    id: '6',
    title: 'Cloud Computing with AWS',
    description: 'Learn cloud architecture, deployment, and DevOps practices. Become AWS certified and job-ready.',
    instructor: 'David Kumar',
    price: 3999,
    duration: '18 weeks',
    level: 'Advanced',
    image: 'https://images.pexels.com/photos/518258/pexels-photo-518258.jpeg?auto=compress&cs=tinysrgb&w=800',
    rating: 4.8,
    students: 650,
    category: 'Cloud Computing',
    modules: ['AWS Basics', 'EC2 & Storage', 'Networking', 'Databases', 'Security', 'Certification Prep']
  }
];

export const liveClasses: LiveClass[] = [
  {
    id: '1',
    title: 'JavaScript Advanced Concepts',
    instructor: 'Sarah Johnson',
    date: '2025-01-25',
    time: '19:00',
    duration: '2 hours',
    price: 499,
    maxStudents: 50,
    enrolledStudents: 32,
    description: 'Deep dive into closures, async/await, and modern JS patterns'
  },
  {
    id: '2',
    title: 'Data Visualization Workshop',
    instructor: 'Dr. Michael Chen',
    date: '2025-01-26',
    time: '15:00',
    duration: '3 hours',
    price: 699,
    maxStudents: 30,
    enrolledStudents: 18,
    description: 'Create stunning visualizations with D3.js and Python'
  },
  {
    id: '3',
    title: 'UX Research Methods',
    instructor: 'Emma Rodriguez',
    date: '2025-01-27',
    time: '17:00',
    duration: '1.5 hours',
    price: 399,
    maxStudents: 40,
    enrolledStudents: 25,
    description: 'Learn user interviews, usability testing, and research analysis'
  }
];

export const mockSessions: Session[] = [
  {
    id: '1',
    courseId: '1',
    courseName: 'Full Stack Web Development',
    tutorName: 'Sarah Johnson',
    studentName: 'John Doe',
    date: '2025-01-24',
    time: '14:00',
    duration: '1 hour',
    meetLink: 'https://meet.google.com/abc-defg-hij',
    status: 'upcoming'
  },
  {
    id: '2',
    courseId: '2',
    courseName: 'Data Science with Python',
    tutorName: 'Dr. Michael Chen',
    studentName: 'Jane Smith',
    date: '2025-01-25',
    time: '10:00',
    duration: '1 hour',
    meetLink: 'https://meet.google.com/xyz-uvwx-rst',
    status: 'upcoming'
  }
];