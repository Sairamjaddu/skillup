export interface User {
  id: string;
  name: string;
  email: string;
  profileImage?: string;
  role: 'student' | 'tutor';
  enrolledCourses?: string[];
}

export interface Course {
  id: string;
  title: string;
  description: string;
  instructor: string;
  price: number;
  duration: string;
  level: 'Beginner' | 'Intermediate' | 'Advanced';
  image: string;
  rating: number;
  students: number;
  category: string;
  modules: string[];
}

export interface Session {
  id: string;
  courseId: string;
  courseName: string;
  tutorName: string;
  studentName: string;
  date: string;
  time: string;
  duration: string;
  meetLink?: string;
  status: 'upcoming' | 'completed' | 'cancelled';
}

export interface LiveClass {
  id: string;
  title: string;
  instructor: string;
  date: string;
  time: string;
  duration: string;
  price: number;
  maxStudents: number;
  enrolledStudents: number;
  description: string;
}